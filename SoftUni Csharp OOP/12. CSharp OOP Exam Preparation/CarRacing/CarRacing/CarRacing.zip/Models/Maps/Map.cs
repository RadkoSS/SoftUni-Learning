﻿namespace CarRacing.Models.Maps
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Contracts;
    using Racers.Contracts;

    public class Map : IMap
    {
        public string StartRace(IRacer racerOne, IRacer racerTwo)
        {
            throw new NotImplementedException();
        }
    }
}
